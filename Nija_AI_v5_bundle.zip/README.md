# Nija AI v5 Trading Bot (Auto-Start)

This repository contains the Nija AI v5 trading bot with two processes:
- Real-time WebSocket trading (`nija_bot_ws.py`)
- Flask dashboard (`nija_bot_web.py`)

## Setup (local / Codespaces)

1. Create a Python virtual environment and activate it (optional but recommended):
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Create a `.env` file based on `.env.example` and set your real keys (do NOT commit `.env`):
   ```
   COINBASE_API_KEY=your_key_here
   COINBASE_API_SECRET=your_secret_here
   TV_WEBHOOK_SECRET=your_webhook_secret
   PORT=5000
   ```

4. Run locally for testing:
   ```bash
   python nija_bot_ws.py
   # in another shell:
   python nija_bot_web.py
   ```

## Deploy (Render / Railway)

1. Push this repo to GitHub.
2. Create a new Web Service on Render or a new Project on Railway and connect your GitHub repo.
3. Set environment variables in the platform UI:
   - COINBASE_API_KEY
   - COINBASE_API_SECRET
   - TV_WEBHOOK_SECRET
   - PORT (usually set automatically by platform)
4. Deploy — the Procfile runs `start_nija.sh` which starts the WebSocket bot and the Flask dashboard.

## WARNING
This bot will place **live market orders** using the Coinbase API. Make sure you:
- Use API keys with appropriate permissions.
- Test on a small account or sandbox before scaling.
- Understand the financial risk: live trading can lose money.