import os
import pandas as pd
import numpy as np
from coinbase_advanced_py import CoinbaseClient
from datetime import datetime

# IMPORTANT: Set your API keys as environment variables (see .env.example)
API_KEY = os.getenv("COINBASE_API_KEY")
API_SECRET = os.getenv("COINBASE_API_SECRET")
if not API_KEY or not API_SECRET:
    print("WARNING: COINBASE_API_KEY or COINBASE_API_SECRET not set. Set them in environment or .env before running in production.")

client = CoinbaseClient(API_KEY, API_SECRET)
TRADING_PAIRS = ["BTC-USD", "ETH-USD"]
RISK_PERCENT = 5

# store live data per pair
live_data = {pair: pd.DataFrame(columns=["time","price","volume"]) for pair in TRADING_PAIRS}

def get_account_balance(symbol="USD"):
    try:
        accounts = client.get_accounts()
        for acct in accounts:
            if acct.get('currency') == symbol:
                return float(acct.get('available', 0))
    except Exception as e:
        print(f"❌ Error fetching {symbol} balance:", e)
    return 0.0

def calculate_position_size(balance, risk_percent=RISK_PERCENT):
    size = balance * (risk_percent / 100)
    return round(size, 8)

def update_live_data(pair, price, volume, timestamp):
    global live_data
    df = live_data.get(pair)
    row = {"time": timestamp, "price": price, "volume": volume}
    df = df.append(row, ignore_index=True)
    live_data[pair] = df.tail(200)

def calculate_vwap(df):
    return (df['price'] * df['volume']).sum() / df['volume'].sum() if (not df.empty and df['volume'].sum() > 0) else 0

def calculate_rsi(df, period=14):
    if df.empty or len(df) < period:
        return 50.0
    delta = df['price'].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(period).mean()
    avg_loss = loss.rolling(period).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return float(rsi.iloc[-1])

def ai_signal(pair):
    df = live_data.get(pair)
    vwap = calculate_vwap(df)
    rsi = calculate_rsi(df)
    latest_price = float(df['price'].iloc[-1]) if df is not None and (not df.empty) else 0
    # Basic weighted decision
    if latest_price > vwap and rsi < 70:
        return "buy"
    if latest_price < vwap and rsi > 30:
        return "sell"
    return "hold"

def place_order(symbol, side, amount):
    try:
        # Coinbase expects size in base currency units; ensure amount format fits your account/currency.
        order = client.place_order(
            product_id=symbol,
            side=side,
            order_type="market",
            size=str(amount)
        )
        print(f"✅ {datetime.now()} | Order: {side} {amount} {symbol}")
        return order
    except Exception as e:
        print(f"❌ Error placing order for {symbol}:", e)
        return None