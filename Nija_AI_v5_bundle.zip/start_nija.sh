#!/bin/bash
# Auto-start the WebSocket bot in background and run dashboard via gunicorn

# Activate virtualenv if present
if [ -f ".venv/bin/activate" ]; then
    source .venv/bin/activate
fi

python nija_bot_ws.py &

# Start Flask dashboard
exec gunicorn nija_bot_web:app --bind 0.0.0.0:$PORT