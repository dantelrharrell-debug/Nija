import asyncio
import websockets
import json
from datetime import datetime
from nija_bot import TRADING_PAIRS, update_live_data, ai_signal, get_account_balance, calculate_position_size, place_order

COINBASE_WS_URL = "wss://ws-feed.exchange.coinbase.com"

async def subscribe():
    async with websockets.connect(COINBASE_WS_URL) as ws:
        await ws.send(json.dumps({
            "type": "subscribe",
            "product_ids": TRADING_PAIRS,
            "channels": ["ticker"]
        }))
        print("🟢 Connected to Coinbase WebSocket")

        async for message in ws:
            msg = json.loads(message)
            if msg.get("type") == "ticker":
                pair = msg.get("product_id")
                try:
                    price = float(msg.get("price", 0) or 0)
                except:
                    price = 0.0
                try:
                    volume = float(msg.get("last_size", 0) or 0)
                except:
                    volume = 0.0
                timestamp = datetime.now()
                update_live_data(pair, price, volume, timestamp)

                decision = ai_signal(pair)
                balance = get_account_balance("USD")
                size = calculate_position_size(balance)

                if decision in ["buy", "sell"] and size > 0:
                    place_order(pair, decision, size)

def run_bot():
    asyncio.get_event_loop().run_until_complete(subscribe())

if __name__ == "__main__":
    run_bot()