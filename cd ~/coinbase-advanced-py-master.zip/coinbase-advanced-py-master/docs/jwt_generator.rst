Authentication
-----------------------------

.. automodule:: coinbase.jwt_generator
   :members:
   :undoc-members:
   :show-inheritance: